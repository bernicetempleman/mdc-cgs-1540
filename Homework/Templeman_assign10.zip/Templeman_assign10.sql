﻿--Programmer: Bernice Templeman
--Assignment 10
--Complete ALL of Problem 9 on page 533 including ALTER statements in 9b, 9c, 9d
--Write INSERT statements for each table in Problem 9 with at least 5 records. You can make up your own data.
--Name the SQL script file <your_last_name>_assign10.sql and upload it by clicking on the "Browse My Computer" button below.

USE [bernice.templeman001]
GO

DROP TABLE prescription;
DROP TABLE physician;
DROP TABLE medication;
DROP TABLE patient;

CREATE TABLE  patient
(
Pat_pid			char(7) NOT NULL,
Pat_name     	char (41) NULL,
Pat_occup    	char(31) NULL,
Pat_gender  	char(1) NULL,
Pat_age         smallint NULL,
Pat_ins         char(31) NULL,
CONSTRAINT pk_patient PRIMARY KEY (Pat_pid),
CONSTRAINT chk_gender CHECK (Pat_gender IN ('M', 'F')),
CONSTRAINT chk_age CHECK (Pat_age BETWEEN 0 AND 90)
);

CREATE TABLE medication
(
Med_name      	char(31) NOT NULL,
Med_code        char(5) NOT NULL,
Med_listprice   decimal(3,2) NULL,
CONSTRAINT pk_medication PRIMARY KEY (Med_code),
CONSTRAINT uq_med_name UNIQUE(Med_name),
CONSTRAINT ck_listprice CHECK ( Med_listprice < 10.00)
);

CREATE TABLE physician
(
Phy_ph#     	integer NOT NULL,
Phy_name      	char(41) NOT NULL,
Phy_phone 		numeric NOT NULL,
Phy_experience	integer NULL,
Phy_specialty  	integer NULL,
CONSTRAINT pk_physician PRIMARY KEY (Phy_ph#),
CONSTRAINT uq_phy_name UNIQUE(Phy_name),
CONSTRAINT ck_experience CHECK (Phy_experience BETWEEN 1 AND 70)
);

CREATE TABLE prescription
(
Pre_p#         	char (13) NOT NULL,
Pre_date      	datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
Pre_dosage      smallint NULL,
Pre_freq      	smallint NULL,
Pre_pat_pid		char (7),
Pre_med_code  	char(5),
Pre_phy_Ph#     integer,
CONSTRAINT pk_prescription PRIMARY KEY (Pre_p#),
CONSTRAINT ck_dosage CHECK ( Pre_dosage BETWEEN 1 AND 3),
CONSTRAINT ck_frequency CHECK ( Pre_freq  BETWEEN 1 AND 3),
CONSTRAINT fk_prescription1 
	FOREIGN KEY(Pre_pat_pid)
	REFERENCES patient (Pat_pid),
CONSTRAINT fk_prescription2 
	FOREIGN KEY(Pre_med_code)
	REFERENCES medication (Med_code),
CONSTRAINT fk_prescription3 
	FOREIGN KEY(Pre_phy_Ph#)
	REFERENCES physician (Phy_ph# )
);


--9b: 
ALTER TABLE medication
	ADD Med_unit_cost decimal(3,2)
	CONSTRAINT ck_unit_cost CHECK (Med_unit_cost between 0.50 AND 7.50);

--9c:
ALTER TABLE medication
   ADD 
   CONSTRAINT ck_list_price 
   CHECK (Med_listprice >=  Med_unit_cost + (Med_unit_cost * 0.2));

--9d:
ALTER TABLE PATIENT
DROP column Pat_occup;

--Write INSERT statements for each table in Problem 9 with at least 5 records. You can make up your own data.

INSERT INTO patient
	VALUES('1234560','Lisauckis, Hal','M', 69, 'BlueCross' );
INSERT INTO patient
	VALUES('1234561', 'Hargrove, Jan', 'F', 21, 'BlueCross' );
INSERT INTO patient
	VALUES('1234562','Robbins, Nancy', 'F', 22, 'BlueCross');
INSERT INTO patient
	VALUES('1234563', 'Grimes, David', 'M', 23, 'BlueCross');
INSERT INTO patient
	VALUES('1234564', 'Davis, Gina', 'F', 24, 'BlueCross');


INSERT INTO MEDICATION VALUES('Vibramycin', 'VIB', 1.5,1.0 );
INSERT INTO MEDICATION VALUES('Keflin','KEF', 2.5, 2.0 );
INSERT INTO MEDICATION VALUES('Aspirin', 'ASP', 1.1, 0.5);
INSERT INTO MEDICATION VALUES('Penicillin', 'PCN', 1.5, 1.0);
INSERT INTO MEDICATION VALUES('Valium', 'VAL', 1.75, 1.00);

INSERT INTO PHYSICIAN
	VALUES( 1, 'Dr. Carlos Perez', 3051234567, 1, 1);
INSERT INTO PHYSICIAN
	VALUES( 2, 'Dr Kevin Fox', 3051234568 , 2,2 );
INSERT INTO PHYSICIAN
	VALUES( 3, 'Dr. Susan Lurie', 3051234569, 3, 3);
INSERT INTO PHYSICIAN
	VALUES( 4, 'Dr Lydia Puente',  3051234560, 4, 4);
INSERT INTO PHYSICIAN
	VALUES( 5, 'Dr Steven Santiago', 3051234561, 5,5 );


INSERT INTO  prescription
	VALUES( '1234567890','2014-06-01', 1, 2, '1234560', 'VIB', 1);
INSERT INTO  prescription
	VALUES( '1234567891','2014-06-01', 2, 2, '1234561', 'KEF', 2);
INSERT INTO  prescription
	VALUES( '1234567892','2014-06-01', 3, 1, '1234562', 'ASP', 3);
INSERT INTO  prescription
	VALUES( '1234567893','2014-06-01', 1, 1, '1234563', 'PCN', 4);
INSERT INTO  prescription
	VALUES( '1234567894','2014-06-01', 1, 2, '1234564', 'VAL', 5) ;


	-- see contents of PATIENT table
	SELECT * FROM patient

	-- see contents of MEDICATION table
	SELECT * FROM medication

	-- see contents of PHYSICIAN table
	SELECT * FROM physician

	-- see contents of PRESCRIPTION table
	SELECT * FROM prescription

	